package com.example.taleRepair

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
